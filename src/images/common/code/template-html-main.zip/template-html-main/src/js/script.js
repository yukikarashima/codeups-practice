
jQuery(function ($) { // この中であればWordpressでも「$」が使用可能になる


});
